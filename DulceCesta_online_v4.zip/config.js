// 1) Crea un proyecto en Supabase.
// 2) Copia aquí SOLO la Project URL y la Publishable/Anon key.
// 3) NUNCA pongas aquí una service_role/secret key.
//
// Puedes dejar estos valores vacíos para abrir la web en modo DEMO local.
window.DULCECESTA_CONFIG = {
  supabaseUrl: "",
  supabaseKey: ""
};
